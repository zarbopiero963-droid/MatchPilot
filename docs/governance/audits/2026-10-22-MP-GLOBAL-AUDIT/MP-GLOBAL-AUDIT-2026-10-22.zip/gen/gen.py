import json, collections, sys
sys.path.insert(0,'.')
from judg import J
from gaps import G, ORPHAN
base='/tmp/claude-0/-home-user-MatchPilot/9501c668-6355-52e9-bcad-bf70034a666f/scratchpad/'
d=json.load(open(base+'audit-main/docs/governance/mp-pr-00/requirements.json'))
LV={'NI':'not implemented','INI':'implemented, not integrated','II':'implemented and integrated','CC':'certified component','CI':'certified integrated','PROC':'N/A (process-only)'}
TESTFILES_RUN=True
rows=[]
for r in d['requirements']:
    a,l,res,note=J[r['id']]
    rows.append({'id':r['id'],'group':r['group'],'source':r['source'],'priority':r['priority'],'statement':r['statement'],
      'code':r['code'],'tests':r['tests'],'evidence':r['evidence'],'declared_verdict':r['verdict'],
      'audited_status':a,'implementation_level':LV[l],'residual':res,'note':note,
      'discrepancy': (a!=r['verdict']) or ('stale' in note)})
assert len(rows)==139 and set(J)==set(x['id'] for x in rows)
cs=collections.Counter(x['audited_status'] for x in rows)
cl=collections.Counter(x['implementation_level'] for x in rows)
cd=collections.Counter(x['declared_verdict'] for x in rows)
trans=collections.Counter((x['declared_verdict'],x['audited_status']) for x in rows if x['declared_verdict']!=x['audited_status'])
p0=[x for x in rows if x['priority']=='P0' and x['audited_status']!='PASS']
out={'audit':'B-RTM','repo':'zarbopiero963-droid/MatchPilot','main_head':'39fe08eadaad382550c8994b2be308ee6493111e','date':'2026-10-22',
 'method':{'tests':'node --test --test-concurrency=1 test/*.test.mjs on local PostgreSQL 16.15 (FUTPYTHON_TEST_DATABASE_URL local): 439 tests, 437 pass, 1 fail (governance-workflows: package yaml missing from linked node_modules; 13/13 pass in a clean npm ci copy), 1 skipped (postgres-independence requires PG17). Browser QA tools/qa/browser-qa.mjs 12/12 PASS; visual tools/qa/visual.mjs 45/45 PASS; npm audit --omit=dev high: 0; governance:validate and governance:check PASS.',
   'code':'every code/test path in requirements.json exists on main (24 design entries are prose labels, not paths); functions inspected; runtime reachability computed from src/server.mjs import graph.',
   'levels':LV},
 'counts':{'audited_status':dict(cs),'implementation_level':dict(cl),'declared_verdict':dict(cd),'transitions':{f'{k[0]}->{k[1]}':v for k,v in trans.items()},'p0_not_pass':len(p0)},
 'requirements':rows,
 'gaps':[dict(zip(['id','source','requirement','source_quote','priority','code_hint','note'],g)) for g in G],
 'orphan_code':[dict(zip(['id','location','finding'],o)) for o in ORPHAN]}
json.dump(out,open(base+'audit/B-rtm.json','w'),ensure_ascii=False,indent=1)
esc=lambda s:str(s).replace('|','\\|').replace('\n',' ')
L=[]
L.append('# B — Requirements Traceability Matrix (audit read-only)\n')
L.append('Repository `zarbopiero963-droid/MatchPilot`, main `39fe08e` (2026-10-22). Base: `docs/governance/mp-pr-00/requirements.json` (139 requisiti, schema mp-gate-a-v2), trattato come ipotesi da verificare. Machine-readable: `B-rtm.json`.\n')
L.append('## Metodo\n')
L.append('- '+out['method']['tests']+'\n- '+out['method']['code']+'\n- Livelli: '+', '.join(f'{k}={v}' for k,v in LV.items())+'. PROC = requisito di processo senza codice prodotto.\n- Status: PASS / FAIL / NOT_VERIFIED / BLOCKED (nessun OUT_OF_SCOPE: gli esclusi sono già in future_register).\n- Commit recenti considerati: #184 (segnali simulati), #186 (TC-OFF), #187 (SIM-OUTBOX) e #189 (revert di #187).\n')
L.append('## Conteggi\n')
L.append('| Status auditato | N |\n|---|---|\n'+''.join(f'| {k} | {v} |\n' for k,v in sorted(cs.items())))
L.append('\n| Livello di implementazione | N |\n|---|---|\n'+''.join(f'| {k} | {v} |\n' for k,v in sorted(cl.items())))
L.append('\n| Verdetto dichiarato | N |\n|---|---|\n'+''.join(f'| {k} | {v} |\n' for k,v in sorted(cd.items())))
L.append('\nTransizioni dichiarato→auditato: '+', '.join(f'{k[0]}→{k[1]}: {v}' for k,v in sorted(trans.items()))+'\n')
L.append('\n## Discrepanze rispetto ai verdetti dichiarati\n')
for x in rows:
    if x['discrepancy']: L.append(f"- **{x['id']}** ({x['declared_verdict']}→{x['audited_status']}): {esc(x['residual'])}\n")
L.append('\n## Matrice\n')
L.append('| ID | issue | requisito | codice | test | evidenza | dichiarato | auditato | livello | residuo | prio |\n|---|---|---|---|---|---|---|---|---|---|---|\n')
for x in rows:
    ev='; '.join(e[:70] for e in x['evidence'])
    L.append(f"| {x['id']} | {esc(x['source'])} | {esc(x['statement'][:110])} | {esc(', '.join(x['code']) or '—')} | {esc(', '.join(x['tests']) or '—')} | {esc(ev or '—')} | {x['declared_verdict']} | **{x['audited_status']}** | {x['implementation_level']} | {esc(x['residual'] or '—')} | {x['priority']} |\n")
L.append('\n## Requisiti P0 non PASS ('+str(len(p0))+')\n\n'+', '.join(x['id'] for x in p0)+'\n')
L.append('\n## Gap di copertura (requisiti delle issue non presenti in requirements.json): '+str(len(G))+'\n\n| ID | fonte | requisito | citazione | prio | nota codice |\n|---|---|---|---|---|---|\n')
for g in G: L.append(f"| {g[0]} | {g[1]} | {esc(g[2])} | «{esc(g[3])}» | {g[4]} | {esc(g[5] or '—')} |\n")
L.append('\nI domini #28, #44, #45, #46, #94 (oltre MATH-CORE-01), #95, #96, #99, #100 (oltre gli outcome di backtest), #102 sono coperti solo a livello di dominio da MP-FUT-001..022 (non atomizzati). #45 resta escluso (MP-OWNER-EXCLUDE-REAL-EXECUTION-01); operatività TotalCorner sospesa (#182); Render/Neon esclusi (#182); archivio #40 in sola lettura (D7).\n')
L.append('\n## Codice orfano (non tracciato da alcun requisito)\n\n'+''.join(f"- **{o[0]}** `{o[1]}`: {o[2]}\n" for o in ORPHAN))
open(base+'audit/B-rtm.md','w').write(''.join(L))
print(dict(cs)); print(dict(cl)); print(dict(trans)); print(len(p0), len(G))
print([x['id'] for x in rows if x['discrepancy']])
